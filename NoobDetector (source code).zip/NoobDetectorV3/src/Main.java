import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException {		
		// scanners
		Scanner scanner = new Scanner(System.in);
		
		// prints and userinput
		System.out.println("What is your name? ");
		String name = scanner.next();
		System.out.println("How old are you? ");
		int age = scanner.nextInt();
		System.out.println("What is your favorite food?");
		String food = scanner.next();
		System.out.println("What is your gender?");
		String gender = scanner.next();
		System.out.println("Do you have a job (type true or false) ?");
		boolean job = scanner.nextBoolean();
		
		String noob = "not a noob";
		
		if (job == true && age <= 20) {
			noob = "not a noob";
		} else if (job == false && age >= 20) {
			noob = "a noob";
		}
		
		System.out.print("\nHello "+name+"\nYour age is "+age+"\nYour favorite food is "+food+"\nYour gender is "+gender+"\nHas job? "+job+"\nAnd you are "+noob);

	    System.out.println("\nPress return to continue.");
	    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	    in.readLine();
		scanner.close();
	}

}


